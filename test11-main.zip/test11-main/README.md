
### Aplikacja
> - Aplikacja mObywatelMod w wersji 2.0 to aplikacja kolekcjonerska. 
> 
> - Posiadacz aplikacji mObywatelMod, niezależnie od wersji, **nie ma prawa** używać jej do weryfikacji danych osobowych lub innych czynności które może tylko aplikacja mObywatel 2.0 niezależnie od sytuacji. 
> 
> - Aplikacja mObywatelMod ma za zadanie służyć osobą kolekcjonującym takie aplikacje, a nie imitować aplikacje mObywatel 2.0
> 
> Art. 270 KK
> § 1.  Kto, w celu użycia za autentyczny, podrabia lub przerabia dokument lub takiego dokumentu jako autentycznego używa,
> podlega karze pozbawienia wolności od 3 miesięcy do lat 5.
> §  2.  Tej samej karze podlega, kto wypełnia blankiet, opatrzony cudzym podpisem, niezgodnie z wolą podpisanego i na jego szkodę albo takiego dokumentu używa.
> 
> ——-
> 
> Tak jak wspomniano powyżej, aplikacja mObywatelMod, niezależnie od wersji, to aplikacja która nie ma za zadanie być używana za prawdziwy Dowód Osobisty. 
